package proyectois.cupcakes.resources;
import java.sql.*;


public class Conexionbd 
{

       private static final String URL= "jdbc:postgresql://localhost:5432/cupcakes";
       private static final String username = "postgres";
       private static final String password = "Theclonewarsseason1";    

   
    public static Connection getConexion()
    {
        Connection connection = null;

       try
       {
           
       
           connection = DriverManager.getConnection(URL, username, password);
           System.out.println("Se ha conectado a la base de datos");



           //connection.close();
       }
       catch(Exception e)
       {
         e.printStackTrace();
       }
       return connection;
        
    }
}
